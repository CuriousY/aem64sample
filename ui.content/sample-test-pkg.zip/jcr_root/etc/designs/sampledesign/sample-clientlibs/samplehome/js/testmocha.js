mocha.setup('bdd');

var assert = chai.assert;

describe('Mocha Test on AddNumber', function () {
 it('should return equal values', function () {
    var num = addNumber(5,5);
    assert.equal(num,10,"on the values passed {5,5} in function addNumber() returns expected value" );
  });

 it('should return strictly equal values', function () {
     	var num = addNumber(5,5);
        assert.strictEqual(num,10,"on the values passed {5,5} in function addNumber() returns expected value" );
    });
});

mocha.run();