describe('Jasmine Test on AddNumber', function () {
 it('should return equal values', function () {
    var num = addNumber(5,5);
     expect(num).toEqual(10); 
  });

 it('should return strictly equal values', function () {
     	var num = addNumber(5,5);
        expect(num).toEqual(10);
    });
});
