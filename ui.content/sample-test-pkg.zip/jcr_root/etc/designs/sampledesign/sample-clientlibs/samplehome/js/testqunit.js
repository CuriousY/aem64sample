QUnit.test( "Test Equality", function( assert ) {
    var num = addNumber(5,5);
    console.log(assert);
    assert.equal(num,10,"on the values {5,5} in function addNumber() returns expected value" );
});

QUnit.test( "Test Equality Strictly on Type", function( assert ) {
    var num = addNumber(5,5);
    assert.strictEqual(num,10,"on the values {5,5} in function addNumber() returns expected value and type" );
});


