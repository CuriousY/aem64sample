var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    var panelId = panel.id;
    if (panel.style.display === "block") {
        if(panelId == "jasminepanel"){
            $('.jasmine_html-reporter').hide();
        }
      	panel.style.display = "none";

    } else {
      panel.style.display = "block";
      if(panelId == "jasminepanel"){
            $('.jasmine_html-reporter').show();
      }
    }
  });
}

/* returns addition of two numbers passed
   @param1 - number, @param2 - number
*/

function addNumber(param1,param2){
    return param1 + param2;
}

$(document).ready(function(){
    console.log('report',$('.jasmine_html-reporter').html());
	$('#jasminepanel').append($('.jasmine_html-reporter').html());
    $('.jasmine_html-reporter').hide();
});