package com.nk.sample.core.utils;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.hamcrest.core.IsEqual;
import static org.hamcrest.Matcher.*;
import org.junit.Rule;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.*;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Answers;
import org.mockito.Matchers;
import org.mockito.internal.matchers.GreaterThan;
import static org.mockito.Mockito.*;
import org.powermock.api.mockito.PowerMockito;

import java.util.Collection;

import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;

import com.nk.sample.service.IGetUserService;
import com.nk.sample.service.impl.GetUserServiceImpl;
import org.powermock.core.classloader.annotations.PrepareForTest;

import io.wcm.testing.mock.aem.junit.AemContext;
import org.powermock.modules.junit4.*;

@RunWith(PowerMockRunner.class)
@PrepareForTest({FrameworkUtil.class})
public class OSGIUtilsTest {
	
	@Mock
	private IGetUserService getUserService;
	
	@Mock
	private GetUserServiceImpl userimpl;
	
	@Mock
	private FrameworkUtil frameWorkUtil;
	
	@Rule
	public final AemContext context = new AemContext();
	 
	BundleContext bundleContext;
	
	@Mock
	Bundle bundle;

	@Before
	public <T> void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		context.registerService(IGetUserService.class, getUserService, 
				org.osgi.framework.Constants.SERVICE_RANKING, Integer.MAX_VALUE);
		PowerMockito.mockStatic(FrameworkUtil.class,Answers.RETURNS_DEEP_STUBS);
		bundle = context.bundleContext().getBundle();
		PowerMockito.doReturn(bundle).when(FrameworkUtil.class, "getBundle", getUserService.getClass());
		
	}

	@Test
	public <T> void testSingleServiceReferenceShouldNotBeNull() {
		Bundle bundle = FrameworkUtil.getBundle(getUserService.getClass());
		bundleContext = bundle.getBundleContext();
		ServiceReference osgiRef = bundleContext.getServiceReference(IGetUserService.class);
		
        T serviceRef = (T) bundleContext.getService(osgiRef);
		assertNotNull(serviceRef);
	}

}
